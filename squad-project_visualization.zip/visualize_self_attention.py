"""Test a model and generate submission CSV.

Usage:
    > python test.py --split SPLIT --load_path PATH --name NAME
    where
    > SPLIT is either "dev" or "test"
    > PATH is a path to a checkpoint (e.g., save/train/model-01/best.pth.tar)
    > NAME is a name to identify the test run

"""

import csv
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data as data
import util

from args import get_test_args
from json import dumps
from ujson import load as json_load
from util import collate_fn, SQuAD
import common
import matplotlib.pyplot as plt
#plt.switch_backend('agg')
import matplotlib.ticker as ticker

def showAttention(input_sentence,attentions):
    # Set up figure with colorbar
    fig = plt.figure()
    ax = fig.add_subplot(111)
    cax = ax.matshow(attentions[0].detach().numpy(), cmap='bone')
    fig.colorbar(cax)

    ax.set_xticklabels([''] + input_sentence, rotation=90)
    ax.set_yticklabels([''] + input_sentence)    
    plt.show()


def convertwrdId_word(list_wordIds,args):
    with open(args.word2idx_file, 'r') as fh:
         words_dict = json_load(fh)
    inverted_dict = dict([[v,k] for k,v in words_dict.items()])
    list_words=[]
    for i,wordId in enumerate(list_wordIds):
        list_words.append(inverted_dict.get(wordId))
    return list_words
        
    


def visualize_self_attention(args, q_id):
    # Set up logging
    args.save_dir = util.get_save_dir(args.save_dir, args.name, training=False)
    log = util.get_logger(args.save_dir, args.name)
    log.info('Args: {}'.format(dumps(vars(args), indent=4, sort_keys=True)))
    device, gpu_ids = util.get_available_devices()
    args.batch_size *= max(1, len(gpu_ids))

    # Get embeddings
    log.info('Loading embeddings...')
    word_vectors = util.torch_from_json(args.word_emb_file)

    # Get model
    log.info('Building model...')
    
    log.info('Loading char embeddings...')
    char_vectors = util.torch_from_json(args.char_emb_file)
    model = common.make_model(log, args.model_name, word_vectors=word_vectors,
                  hidden_size=args.hidden_size,char_vectors=char_vectors,visualize=True
                  )
    
    model = nn.DataParallel(model, gpu_ids)
    log.info('Loading checkpoint from {}...'.format(args.load_path))
    model = util.load_model(model, args.load_path, gpu_ids, return_step=False)
 

    model = model.to(device)
    model.eval()
    
    # subset = data.Subset(dataset,l) , can be used for dataloader filtering
    
    # Get data loader
    log.info('Building dataset...')
    record_file = vars(args)['{}_record_file'.format(args.split)]
    dataset = SQuAD(record_file, args.use_squad_v2)
    data_loader = data.DataLoader(dataset,
                                  batch_size=args.batch_size,
                                  shuffle=False,
                                  num_workers=args.num_workers,
                                  collate_fn=collate_fn
                                  )

    for cw_idxs, cc_idxs, qw_idxs, qc_idxs, y1, y2, ids in data_loader:
        # Setup for forward
        cw_idxs = cw_idxs.to(device)
        qw_idxs = qw_idxs.to(device)
        cc_idxs = cc_idxs.to(device)
        qc_idxs = qc_idxs.to(device)

        _, _,raw_attn = model(cw_idxs, cc_idxs, qw_idxs, qc_idxs)      
        context = convertwrdId_word(cw_idxs[0].numpy(),args)
        showAttention(context,raw_attn[0])
        



if __name__ == '__main__':
    visualize_self_attention(get_test_args(),1) # 1 is the dummy id 

